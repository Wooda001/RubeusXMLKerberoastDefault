from panther_base_helpers import deep_get, pattern_match
## Required
#
# The logic to determine if an alert should send.
# return True = Alert, False = Do not Alert
def rule(event):
    fullDtg = event.get("timestamp")
    time = fullDtg[11:16] #Pulling the hours only as date is not needed for this detection. New object also allows timestamp to remain intact.
    #Earliest login based on 6:45AM EST & Latest login shouldn't be past 5:15 EST
    return event.get("resource") == "admin-dash" and (time < '11:45' or time > '22:15')  


## Optional Functions
#
# Set custom alert titles, must return a string.
# If not defined, defaults to the rule display name or rule ID.
def title(event):
    return f"After hours login event detected for {event.get('login')} at {event.get('timestamp')}"


# Set custom deduplication strings, must return a string.
# If not defined, defaults to the alert title.
def dedup(event):
    return event.get("login")
