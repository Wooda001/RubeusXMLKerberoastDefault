from panther_base_helpers import deep_get, pattern_match
## Required
#
# The logic to determine if an alert should send.
# return True = Alert, False = Do not Alert
def rule(event):
    return event.get("action") == "Login failed. Attempt: 1"


## Optional Functions
#
# Set custom alert titles, must return a string.
# If not defined, defaults to the rule display name or rule ID.
def title(event):
    return f"Possible Password Spraying event detected from {event.get('ip_address')}"


# Set custom deduplication strings, must return a string.
# If not defined, defaults to the alert title.
def dedup(event):
    return event.get("ip_address")
